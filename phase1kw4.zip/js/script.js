function log(info) {
  if (Object.keys(info).length == 0) {
    return false;
  } else{
    return true;
  }
}

function isOwner(info) {
  if (info.role == 'owner') {
    return true;
  } else {
    return false;
  }
}

function isCoWorker(info) {
  if (info.role == 'Co-Worker') {
    return true;
  } else {
    return false;
  }
}

function Loged(file) {
  return new Promise((resolve) => {
      return fetch(file).then(function(response) {
          const json = response.json();
          if (json) {
              resolve(json);
          } 
      });
  });
}

Loged("/accountuse.json").then(data => {
  info = data;
  nav(info)
})

function createNavigationLink(label, url) {
  var navigation = document.getElementById('menu');
  var a = document.createElement('a');
  var li = document.createElement('li');
  a.setAttribute('href', url);
  var label = document.createTextNode(label);
  li.appendChild(a);
  a.appendChild(label);
  navigation.appendChild(li);
}

 function nav(info) {
  if (log(info)) {
    if (isOwner(info)) {
      createNavigationLink('Add New', 'addP.html');
      createNavigationLink('My Properties', 'myP.html');
    } else {
      createNavigationLink('All Workspaces', 'allW.html');
      createNavigationLink('Search', 'search.html');
    }
    createNavigationLink('Sign Out', 'signout.html');
  } else {
    createNavigationLink('Signup', 'signup.html');
    createNavigationLink('Login', 'login.html');
  }
};